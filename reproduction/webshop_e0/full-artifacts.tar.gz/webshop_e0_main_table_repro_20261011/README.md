# WebShop E0 Main-Table Reproduction Artifacts

This bundle exports the archived evaluation that produced the paper's WebShop
**Score 69.9 / success 42.2%**. It does not contain newly generated patches or
new target rollouts. The engineer was the identity-clean **iter143** checkpoint.

| Metric | Archived no-harness baseline | Archived E0 rerun |
|---|---:|---:|
| Tasks | 500 | 500 |
| Successes | 156 (31.2%) | 211 (42.2%) |
| Mean reward | 0.6595866666666667 | 0.69923 |
| Valid patches / completed patched batches | - | 50 / 50 |

All 500 archived baseline/rerun task manifests match exactly. The tasks are
indices **0 through 499**, in file order, grouped into **50 consecutive batches
of 10**. There was no task shuffle in the evaluation driver. Task indices refer
to the WebShop goal list after the seeded goal shuffle described below.

## Files

- `data/tasks.jsonl`: all 500 task instructions, initial user messages, complete
  task manifests, and baseline/patched per-task rewards.
- `data/engineer_inputs.jsonl`: the 50 materialized model-facing prompts used
  for the archived run, with task identity and baseline metadata. Only private
  filesystem paths in metadata were removed; prompt messages are unchanged.
- `data/engineer_prompt_prefix.json`: the exact shared system/user prefix.
- `patches/webshop_noharness_bNNN/patch.json`: the original 50 evaluated patches.
- `patches/webshop_noharness_bNNN/raw_response.txt`: their original raw outputs.
- `data/baseline_rollouts.jsonl` and `data/patched_rollouts.jsonl`: the archived
  messages, task manifests, rewards, and terminal statuses for both conditions.
- `data/batch_results.json`, `data/summary.json`, `data/evaluation_settings.json`,
  and `data/provenance.json`: batch scores, settings, hashes, and source records.
- `data/environment_snapshot.json.gz`: the verified first 500 goals and full
  product-price map, reconstructed from retained assets and matched to every
  archived task manifest. This is an environment reference, not model input.
- `verify_environment.py`: initialize the installed WebShop environment and
  compare all 500 identities without requesting any model.
- `fixes/webshop_goal_seed.patch`: the missing initialization fix, to apply on
  top of the original public release's WebShop dependency patch.
- `fixes/webshop.full.patch`: the complete updated dependency patch for a clean
  WebShop checkout. `fixes/public_release.patch` updates the Harness-R1 release
  checkout itself (dependency patch and setup documentation).
- `run_eval.sh`: replay the original patches or regenerate patches from the
  original prompts, using the public evaluator.

## Important Prompt Difference

The archived main-table WebShop run used **`webshop_code_only`**, not
`webshop_life_multihook_v1`. This is confirmed by both `run_config.json` and the
materialized input messages. The two schemas share the code-hook API but give
different instructions to the engineer. The main-table prefix permits all four
hook positions; all 50 patches generated in this run used `on_before_action`.
They were not subsequently masked to one hook.

For exact prompt reproduction, use the bundled input file. Merely changing the
schema label in another JSONL does not replace its model-facing prompt.

## Environment Initialization

The WebShop upstream revision was
`64fa2a5c15c7daa698b9ac93f5bb5437b634c9bd`, with the AgentBench WebShop patch and
the additional deterministic-initialization fix. The archived upstream source
ZIP identifies this revision. A Git revision alone does not capture the local
dependency modifications.

Initialization in the paper environment does the following:

1. Save Python's random state and call `random.seed(goal_seed)` **before**
   loading products, sampling product prices, and generating goal price limits.
2. Call `random.seed(goal_seed)` **again** immediately before shuffling goals.
   This keeps goal ordering independent of the number of earlier random draws.
3. Restore the saved random state after construction of the shared simulator.

Both seeds are **233**. The unpatched upstream implementation seeds only the
final shuffle. Passing `goal_seed=233` into its `WebAgentTextEnv(**kwargs)` does
not by itself seed product-price generation.

The original public `webshop.patch` omitted the additional dependency fix.
Apply the bundled incremental patch inside the installed WebShop source tree
(the tree containing `web_agent_site`, not the Harness-R1 repository root):

```bash
git apply --check /path/to/this-bundle/fixes/webshop_goal_seed.patch
git apply /path/to/this-bundle/fixes/webshop_goal_seed.patch
```

This patch is for the original release dependency. If the source already has
the full fix, do not apply it again. New Docker images should instead use the
updated full `webshop.patch` in the public-release working copy.

The expected full product-price-map hash, using the repository's canonical
manifest serialization, is:

```text
9f44958915599c0b494c1b6b94c8e57d2011058f779e49deb20a025716817438
```

This is not a hash of a JSON data file. Goal, instruction, and combined task
hashes for each task are in `data/tasks.jsonl`. A matching price hash alone is
insufficient; verify all task manifests too.

Use the actual worker Python and its actual installed WebShop module:

```bash
export JAVA_HOME=/path/to/jdk11
export PYTHONPATH=/path/to/WebShop
/path/to/webshop-worker/bin/python /path/to/this-bundle/verify_environment.py \
  --output /new/path/environment_check.json
```

Repeat in a second independent process with a different output path. Both
should report `matching_tasks: 500`. To check the reporter's workaround against
the old dependency, add `--outer-seed`. Matching identities establish equality
of task goals, instructions, and prices; they do not establish equality of the
search index, product descriptions, scoring dependencies, or model serving.

### Initialization Checks Completed on 2026-10-11

Three independent Python processes loaded the full data and real Lucene index:

| Source / initialization | Goals | Matching archived task manifests |
|---|---:|---:|
| Retained local dependency with the paper initialization fix | 12087 | 500/500 |
| Original release dependency plus outer `random.seed(233)` | 12087 | 500/500 |
| Original release dependency plus the bundled dependency fix | 12087 | 500/500 |

All three produced the expected product-price hash and 1,181,430 unique products.
The reporter's workaround therefore reproduces the archived task identities
when used with these same assets and this seed. Restoring the caller's RNG
state and supporting nondefault seeds still require the full dependency fix.
This test does not establish that the reporter's own asset files match ours.

The retained worker environment measured for these checks is Python 3.9.25,
Java 11.0.31 (Temurin), pyserini 0.17.1, faiss-cpu 1.7.4, NumPy 1.26.4,
spaCy 3.7.5, en_core_web_lg 3.7.1, and torch 1.11.0. This is a measurement of
the retained environment, not a contemporaneous immutable lockfile from the
July experiment. The goal/price identity matches above are directly verified.
Full JSON reports and checksums of the three data files and all Lucene index
files are under `verification/`. Rebuilt Lucene indexes can differ at the byte
level even when they are semantically equivalent; the recorded hashes identify
the retained index snapshot.

If your host exports `LD_LIBRARY_PATH` pointing at another Python environment's
torch libraries, remove those entries for the worker. In our current host
session this caused a Python 3.9/3.12 torch import conflict; the checks succeeded
with `env -u LD_LIBRARY_PATH -u LD_PRELOAD` before the worker Python command.

## Archived Inference Settings

| Setting | Engineer | Target |
|---|---|---|
| Model | identity-clean E0 iter143 | vanilla Qwen3.5-9B |
| Temperature | 0 | 0 |
| Top-p | 1 | request default |
| Max output tokens | 12288 | 4096 |
| Thinking | enabled | disabled |
| Assistant prefill | `<think>\n` (actual newline) | none |
| Tool choice | no tool schema sent | `auto` |
| Concurrency | 8 batches | 10 tasks within each batch |
| Environment horizon | - | 20 rounds |

The engineer used SGLang, with the base Qwen3.5-9B tokenizer, the tokenizer's
default chat template, TP1/DP1, BF16, context length 32768, and the Triton
attention/PyTorch sampling backends. These settings are recorded in its
archived server startup log. No separate reasoning parser was configured.

The evaluator appends the assistant prefill and sends
`continue_final_message=true`. It did not send an explicit stop string; normal
server/tokenizer termination applied. All 50 archived responses have
`finish_reason=stop`. The configuration allows up to 3 retries (4 attempts) for
request failures; it does not select the best patch by rerun reward. Invalid
patches normally count as no-patch. This particular run has 50 valid patches.

For vLLM versions that require it, `add_generation_prompt=false` is consistent
with continuing an existing assistant message. The wrapper below sends it only
when `ENGINEER_BACKEND=vllm`. Tokenizer/template and serving differences may
still change generated text even at temperature zero.

The original baseline used one controller for its 50 worker batches. Each
patched-batch evaluator invocation used its own controller port and a fresh
worker process; this was a local worker-Python setup. Within a batch the
simulator is shared and sessions are per episode. Persistent shared controllers
must isolate task registrations across runs; duplicate task names can reuse
stale task configurations. The provided wrapper expects unused port ranges.

## Suggested Diagnostic Sequence

First check environment identity. Then replay the archived patches to examine
target/runtime behavior without engineer generation. Finally regenerate patches
from the bundled original prompts to examine the engineer-serving path.

```bash
export REPO=/path/to/Harness-R1
export EVAL_PYTHON=/path/to/evaluator/bin/python
export AGENTBENCH_PYTHON=/path/to/controller/bin/python
export WEBSHOP_WORKER_PYTHON=/path/to/webshop-worker/bin/python
export TARGET_BASE_URL=http://127.0.0.1:8000/v1
export TARGET_MODEL=Qwen3.5-9B
export CONTROLLER_PORT_BASE=30000
export WORKER_PORT_BASE=31000
export OUTPUT_ROOT=/new/path/e0_patch_replay
bash /path/to/this-bundle/run_eval.sh replay
```

Start with `replay --limit 1` and a separate output directory for a smoke test.
For engineer regeneration, use a new output directory and supply:

```bash
export ENGINEER_BASE_URL=http://127.0.0.1:8001/v1
export ENGINEER_MODEL=harness-r1
export ENGINEER_BACKEND=vllm
export OUTPUT_ROOT=/new/path/e0_patch_regeneration
bash /path/to/this-bundle/run_eval.sh generate
```

These runs compare against the archived baseline metadata. For a new causal
estimate on another serving stack, also collect a matching no-harness rollout
on that stack. Do not interpret replay differences from the archived baseline
as pure patch effects when the target's behavior has changed.

The full product catalog and Lucene index remain official benchmark assets;
they are not replaced by the 500 task instructions. Asset checksums and local
environment verification records are provided separately under `verification/`.
Any exported goal/price snapshot is for simulator verification only and must not
be appended to the engineer prompt or exposed as answers to the target.
