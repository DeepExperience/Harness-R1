Thanks for the detailed reproduction report. We traced the WebShop main-table
result back to its original inputs, patches, and per-task rollout records, and
checked the environment initialization against those records.

The archived run used the identity-clean E0 checkpoint at iter143 and obtained
156/500 -> 211/500 successes, with mean reward
0.6595866666666667 -> 0.69923. All 50 patches were valid and evaluated, and all
500 baseline/patched task manifests match.

For initialization, both the product-price/goal-generation stage and the final
goal-shuffle stage were seeded with **233**. The local WebShop dependency used
for the paper had this fix inside `SimServer`; the original released
`webshop.patch` did not include it. We have prepared the missing dependency
patch, which also restores the caller's Python RNG state after initialization.

We tested your proposed `random.seed(233)` immediately before `WebAgentTextEnv`
construction against the original release dependency, using our retained data
and real search index. It reproduced **all 500 archived task manifests**.
The full dependency fix independently produced the same result. Thus, your
workaround matches our task initialization for seed 233 with the same assets.
The expected `product_prices_sha256` is:

```text
9f44958915599c0b494c1b6b94c8e57d2011058f779e49deb20a025716817438
```

We also found a relevant prompt difference: the WebShop main-table run used
**`webshop_code_only`**, with the materialized prefix aligned to the engineer's
SFT data. It did not use `webshop_life_multihook_v1`. Although both use code
hooks, their model-facing instructions differ. All 50 archived patches used
`on_before_action`, despite the prompt allowing all four hook positions.

The accompanying reproduction bundle includes the 500 task instructions and
manifests, the original 50 engineer inputs and patches, baseline and patched
trajectories, per-task rewards, decoding settings, asset/index checksums, and
an environment verification script. The WebShop upstream revision is
`64fa2a5c15c7daa698b9ac93f5bb5437b634c9bd`, plus the dependency patches described
in the bundle. The engineer used SGLang with temperature 0, top-p 1,
max_tokens 12288, and an assistant prefill of `<think>\n`; no explicit stop
string was sent. All 50 archived outputs terminated with `finish_reason=stop`.

We suggest first comparing your environment against the bundled manifests,
then replaying the original patches, and finally regenerating patches from
the original materialized prompts. This separates environment/runtime
differences from engineer-generation differences. The bundle includes wrappers
for both replay and regeneration; the vLLM regeneration option sends
`add_generation_prompt=false` when continuing the assistant prefill.

The initialization checks establish task identity, but they do not by
themselves explain the remaining reward gap after your local seed fix. The
prompt difference is a concrete discrepancy to resolve first, and the original
patches should make the remaining comparison much easier to diagnose.
