"""Export the archived WebShop E0 run without modifying any experiment files."""

import argparse
import hashlib
import json
import math
import shutil
import sys
from collections import Counter
from pathlib import Path


RUN = Path("outputs/identityv1_after127_newckpts_a0_eval_20260717/identityclean_iter_0000143/webshop_test")


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def jsonl(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")


def read_rollouts(directory):
    rows = {}
    for path in sorted(directory.glob("rollout/*/*/runs.jsonl")):
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            index = row["index"]
            if index in rows:
                raise ValueError("Duplicate rollout index: %s" % index)
            rows[index] = row
    return rows


def portable_rollout(row):
    result = row["output"]["result"]
    return {
        "index": row["index"],
        "output": {
            "status": row["output"]["status"],
            "result": {
                key: result[key]
                for key in ("reward", "webshop_task_manifest", "openai_messages")
            },
        },
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    args = parser.parse_args()
    repo = args.repo.resolve()
    bundle = Path(__file__).resolve().parent
    if (bundle / "data").exists():
        parser.error("data/ already exists; export to a new bundle directory")
    sys.path.insert(0, str(repo / "code/life-harness/AgentBench/scripts"))
    from harness_r1_webshop_identity import manifest_sha256, validate_task_manifest

    run = repo / RUN
    config = read_json(run / "run_config.json")
    source = Path(config["input"])
    original = [json.loads(line) for line in source.read_text().splitlines() if line.strip()]
    assert len(original) == 50
    inputs, tasks, batches, baseline_rows, patched_rows = [], [], [], [], []
    hooks = Counter()
    prefix = None
    model_prompt_hashes = []
    for ordinal, record in enumerate(original):
        metadata = record["metadata"]
        tag = metadata["batch_tag"]
        assert metadata["schema_style"] == "webshop_code_only"
        assert metadata["start"] == ordinal * 10
        assert metadata["end"] == ordinal * 10 + 10
        batch = run / tag
        result = read_json(batch / "result.json")
        assert result["valid_patch"] and result["eval_status"] == "ok"
        baseline = read_rollouts(Path(metadata["source_rollout_dir"]))
        patched = read_rollouts(batch / "eval/webshop/batch_000")
        expected_indices = set(range(metadata["start"], metadata["end"]))
        assert set(baseline) == set(patched) == expected_indices
        for index in sorted(expected_indices):
            before = baseline[index]["output"]["result"]
            after = patched[index]["output"]["result"]
            manifest = validate_task_manifest(before["webshop_task_manifest"], expected_index=index, expected_goal_seed=233)
            assert manifest == after["webshop_task_manifest"]
            assert manifest["sha256"] == metadata["webshop_task_manifests"][str(index)]
            assert before["reward"] == metadata["baseline_rewards"][str(index)]
            assert after["reward"] == result["patched_rewards"][str(index)]
            initial = next(m["content"] for m in before["openai_messages"] if m["role"] == "user")
            instruction = initial.split("Instruction: [SEP] ", 1)[1].split(" [SEP]", 1)[0].strip()
            assert manifest_sha256(instruction) == manifest["instruction_sha256"]
            tasks.append({
                "index": index, "batch_tag": tag, "instruction": instruction,
                "initial_user_message": initial, "manifest": manifest,
                "baseline_reward": before["reward"], "patched_reward": after["reward"],
            })
            baseline_rows.append(portable_rollout(baseline[index]))
            patched_rows.append(portable_rollout(patched[index]))
        public_metadata = {
            key: value for key, value in metadata.items()
            if key not in ("source_run_root", "source_rollout_dir", "prompt_prefix_reference")
        }
        inputs.append({**record, "metadata": public_metadata})
        model_prompt_hashes.append({"batch_tag": tag, "prompt_sha256": manifest_sha256(record["prompt"])})
        current_prefix = [dict(m) for m in record["prompt"]]
        current_prefix[-1]["content"] = current_prefix[-1]["content"].split("Observed no-harness rollout evidence:", 1)[0]
        if prefix is None:
            prefix = current_prefix
        assert current_prefix == prefix
        patch_dest = bundle / "patches" / tag
        patch_dest.mkdir(parents=True)
        for name in ("patch.json", "raw_response.txt"):
            shutil.copyfile(batch / name, patch_dest / name)
        patch = read_json(batch / "patch.json")
        hooks.update(action["hook"] for action in patch["actions"])
        response = read_json(batch / "response.json")
        batches.append({
            "batch_tag": tag, "start": metadata["start"], "end": metadata["end"],
            **{key: result[key] for key in (
                "valid_patch", "eval_status", "baseline_pass", "patched_pass", "delta_pass",
                "baseline_average_reward", "patched_average_reward", "delta_average_reward",
                "baseline_task_manifest_sha256", "patched_task_manifests",
            )},
            "patch_file": str(Path("patches") / tag / "patch.json"),
            "patch_file_sha256": sha256(batch / "patch.json"),
            "raw_response_sha256": sha256(batch / "raw_response.txt"),
            "finish_reason": response["choices"][0]["finish_reason"],
            "usage": response.get("usage"),
        })
    summary = read_json(run / "summary.json")
    assert len(tasks) == 500
    for field, reward_key in (("baseline", "baseline_reward"), ("patched", "patched_reward")):
        assert sum(t[reward_key] >= 1 for t in tasks) == summary[field + "_pass"]
        assert math.isclose(sum(t[reward_key] for t in tasks) / 500, summary[field + "_average_reward"], abs_tol=1e-12)
    jsonl(bundle / "data/engineer_inputs.jsonl", inputs)
    jsonl(bundle / "data/tasks.jsonl", tasks)
    jsonl(bundle / "data/baseline_rollouts.jsonl", baseline_rows)
    jsonl(bundle / "data/patched_rollouts.jsonl", patched_rows)
    dump(bundle / "data/prompt_hashes.json", model_prompt_hashes)
    dump(bundle / "data/engineer_prompt_prefix.json", prefix)
    dump(bundle / "data/target_system_prompt.json", baseline_rows[0]["output"]["result"]["openai_messages"][0])
    dump(bundle / "data/batch_results.json", batches)
    dump(bundle / "data/summary.json", summary)
    public_config = {
        key: value for key, value in config.items()
        if not any(part in key for part in ("api_key", "base_url", "python", "port", "dir", "root", "input", "run_id"))
    }
    dump(bundle / "data/evaluation_settings.json", public_config)
    dump(bundle / "data/provenance.json", {
        "archived_run_relative_path": str(RUN),
        "archived_input_relative_path": str(source.relative_to(repo)),
        "archived_input_sha256": sha256(source),
        "archived_run_config_sha256": sha256(run / "run_config.json"),
        "export_date": "2026-10-11",
        "prompt_messages_unchanged": True,
        "metadata_changes": "Removed local source paths only; model-facing prompt messages are unchanged.",
        "source_patches_unchanged": True,
        "task_manifests_matched": 500,
        "product_prices_sha256": sorted({t["manifest"]["product_prices_sha256"] for t in tasks}),
        "hook_counts": dict(hooks),
        "response_finish_reasons": dict(Counter(b["finish_reason"] for b in batches)),
        "schema_style": "webshop_code_only",
        "webshop_upstream_revision": "64fa2a5c15c7daa698b9ac93f5bb5437b634c9bd",
    })
    print(json.dumps({"tasks": len(tasks), "patches": len(batches), "hooks": dict(hooks), "summary": summary}, indent=2))


if __name__ == "__main__":
    main()
